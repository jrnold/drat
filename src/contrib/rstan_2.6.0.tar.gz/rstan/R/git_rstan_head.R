git_head <- function() "198082f07a60928ec8ecfb7f7ae681dd9d10fef9"
