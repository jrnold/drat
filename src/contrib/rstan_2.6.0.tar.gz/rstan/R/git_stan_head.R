git_stan_head <- function() " 39d2ec9e7fe2f4e1f51a4a2194c1459a043b7686 example-models (remotes/origin/HEAD)
+5250745e61c931893c6afeba407ab2a92a5f5c10 stan (v2.6.0)"
