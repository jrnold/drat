#ifndef RSTAN__RSTANINC_HPP
#define RSTAN__RSTANINC_HPP
#include <rstan/stan_fit.hpp>
#endif

