#ifndef STAN__AGRAD__REV__ERROR_HANDLING_HPP
#define STAN__AGRAD__REV__ERROR_HANDLING_HPP

#include <stan/agrad/rev/error_handling/matrix.hpp>

#endif
