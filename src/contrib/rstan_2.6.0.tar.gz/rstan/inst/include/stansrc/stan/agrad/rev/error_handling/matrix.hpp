#ifndef STAN__AGRAD__REV__ERROR_HANDLING__MATRIX_HPP
#define STAN__AGRAD__REV__ERROR_HANDLING__MATRIX_HPP

#include <stan/agrad/rev/error_handling/matrix/check_pos_definite.hpp>

#endif
