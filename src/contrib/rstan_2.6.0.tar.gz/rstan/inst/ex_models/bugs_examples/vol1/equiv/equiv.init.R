mu <- 0
phi <- 0
pi <- 0
sigmasq1 <- 1
sigmasq2 <- 1
delta <- c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0)