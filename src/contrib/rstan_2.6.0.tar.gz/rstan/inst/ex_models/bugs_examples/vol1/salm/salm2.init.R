alpha <- 0
beta <- 0
gamma <- 0
tau <- 0.1
lambda <-
structure(c(0, 0, 0,
            0, 0, 0,
            0, 0, 0,
            0, 0, 0,
            0, 0, 0,
            0, 0, 0), .Dim = c(6, 3))
