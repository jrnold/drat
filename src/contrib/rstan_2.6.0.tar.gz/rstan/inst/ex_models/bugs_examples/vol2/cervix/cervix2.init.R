beta0C <- 0
beta <- 0
q <- 0.5
phi <- structure(c(.5,.5,.5,.5), .Dim = c(2, 2)))
