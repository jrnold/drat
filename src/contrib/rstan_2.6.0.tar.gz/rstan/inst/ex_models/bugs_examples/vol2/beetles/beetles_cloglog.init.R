alpha_star <- 0
beta <- 0

