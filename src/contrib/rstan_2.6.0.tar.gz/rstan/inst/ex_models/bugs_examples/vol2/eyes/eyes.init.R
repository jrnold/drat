lambda_1 <- 535
theta <- 5
sigmasq <- 10
p1 <- 0.5