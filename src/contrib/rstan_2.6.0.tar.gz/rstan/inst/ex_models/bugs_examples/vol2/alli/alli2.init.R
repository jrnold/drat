alpha0 <- c(0,0,0,0)
beta0 <- structure(c(0,0,0,0,
                     0,0,0,0,
                     0,0,0,0),
                   .Dim=c(3,4))
gamma0 <- structure(c(0,0,0,0),
                   .Dim=c(1,4))
lambda <- structure(c(0,0,0,0,
                      0,0,0,0),
                    .Dim=c(4,2))
                    
                    
