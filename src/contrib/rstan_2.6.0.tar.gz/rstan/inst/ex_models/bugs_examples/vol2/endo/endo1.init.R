beta <- 0
